<?php


function sendFirebaseNotification($fb_key_array, $title, $message, $imageURL){
   
   $authorization_key = "AAAACVF-76g:APA91bF0FQn9XpK2XEIN8ierQPG19IUc2MDEjr_huH-kgzALav6-OGjwnfoQezkVNcu9w5psxZKOMe26-w8vrG-h-R9XkTqMfpsi5Ls1XqVewWrq2AL8Frt3Jy6iaDwt1OC6CslAuJr1";

    $finalPostArray = array('registration_ids' => $fb_key_array,
                            'notification' => array('body' => $message,
                                                    'title' => $title,
                                                    "image"=> $imageURL),
                            "data"=> array("click_action"=> "FLUTTER_NOTIFICATION_CLICK",
                                            "sound"=> "default", 
                                            "status"=> "done")); 
    //print_r($finalPostArray);
	
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL,"https://fcm.googleapis.com/fcm/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,json_encode($finalPostArray));  //Post Fields
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json', 'Authorization: key='.$authorization_key));
    $server_output = curl_exec ($ch);
    curl_close ($ch);
	
	
    echo $server_output; 
}

















$title = isset($_POST)?$_POST['title']:"";
$message = isset($_POST)?$_POST['message']:"";
$token = isset($_POST)?$_POST['token']:"";
$arr = array($token);
sendFirebaseNotification($arr,$title,$message,"");










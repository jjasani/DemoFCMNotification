<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="css/bootstrap.min.css" rel="stylesheet"></link>
		<script src="js/jquery-3.5.1.min.js"></script>
		<title>FCM Demo</title>
	</head>
	<body>
		<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
			<a class="navbar-brand" href="#">FCM Demo</a>
		</nav>
		<div class="container pt-3">
			<div class="row">
				<div class="col-lg-3"></div>
				<div class="col-lg-6">
					<h1>FCM Notification Form</h1>
					<form action="send_fcm.php" method="post"> 
						<fieldset>
							<div class="form-group">
								<label for="exampleInputEmail1">Title</label>
								<input type="text" class="form-control" name="title" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter FCM Title">

							</div>
							<div class="form-group">
								<label for="exampleInputPassword1">Message</label>
								<input type="text" class="form-control" name="message" placeholder="Enter FCM Message">
							</div>
							<div class="form-group">
								<label for="exampleInputPassword1">Token</label>
								<input type="text" class="form-control" name="token" placeholder="Enter FCM Message">
							</div>
							<button type="submit" class="btn btn-primary">Submit</button>
						</fieldset>
					</form>
				</div>	
				<div class="col-lg-4"></div>
			</div>	
		</div>	
	</body>
</html>